using Microsoft.Xrm.Sdk;
using System;

public class StarRatingPlugin : IPlugin
{
    public void Execute(IServiceProvider serviceProvider)
    {
        // Obtain the execution context from the service provider
        IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

        // Obtain the Organization Service (for performing CRUD operations)
        IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
        IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

        try
        {
            // Check if the context contains an Entity (the record triggering the plugin)
            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                Entity entity = (Entity)context.InputParameters["Target"];
                
                // Add logic to set the star rating value (example logic)
                if (entity.LogicalName == "new_feedback") // Replace with your custom entity name
                {
                    if (entity.Attributes.Contains("new_starRating"))
                    {
                        entity["new_starRating"] = 5; // Set the star rating value to 5 (for example)
                    }
                    service.Update(entity); // Update the entity with the new star rating
                }
            }
        }
        catch (Exception ex)
        {
            throw new InvalidPluginExecutionException("An error occurred in the StarRatingPlugin.", ex);
        }
    }
}
