import { IInputs, IOutputs } from "./generated/ManifestTypes";

export class StarRatingControl implements ComponentFramework.StandardControl<IInputs, IOutputs> {
    // HTML container to hold the control
    private container: HTMLDivElement;

    constructor() {}

    /**
     * Initializes the control instance and sets up the DOM elements.
     * @param context The execution context for the control.
     * @param notifyOutputChanged Function to notify when outputs have changed.
     * @param state Control state to maintain during a session.
     * @param container The HTML element to host the control.
     */
    public init(
        context: ComponentFramework.Context<IInputs>,
        notifyOutputChanged: () => void,
        state: ComponentFramework.Dictionary,
        container: HTMLDivElement
    ): void {
        // Create the container for the control
        this.container = container;

        // Add HTML for the star rating control
        this.container.innerHTML = `
            <div style="display: flex; align-items: center;">
                <span style="margin-right: 10px;">Rating:</span>
                ${[...Array(5)]
                    .map(
                        (_, index) => `
                            <span 
                                class="star" 
                                style="font-size: 24px; cursor: pointer;" 
                                data-value="${index + 1}">
                                ★
                            </span>
                        `
                    )
                    .join("")}
            </div>
        `;

        // Add event listeners for star clicks
        const stars = this.container.querySelectorAll(".star");
        stars.forEach((star) => {
            star.addEventListener("click", (event) => {
                const value = (event.target as HTMLElement).getAttribute("data-value");
                this.handleStarClick(value ? parseInt(value) : 0);
            });
        });
    }

    /**
     * Updates the control view when data or state changes.
     * @param context The context object containing the control's data.
     */
    public updateView(context: ComponentFramework.Context<IInputs>): void {
        // Update logic can be added here based on `context` inputs
    }

    /**
     * Called when the control output is needed by the framework.
     * @returns The output values of the control.
     */
    public getOutputs(): IOutputs {
        return {};
    }

    /**
     * Cleans up the control instance when it is removed from the DOM.
     */
    public destroy(): void {
        // Remove any event listeners or cleanup tasks
        this.container.innerHTML = "";
    }

    /**
     * Handles the click event for a star and updates the control UI.
     * @param value The selected star rating value.
     */
    private handleStarClick(value: number): void {
        const stars = this.container.querySelectorAll(".star");
        stars.forEach((star, index) => {
            if (index < value) {
                star.setAttribute("style", "font-size: 24px; color: gold; cursor: pointer;");
            } else {
                star.setAttribute("style", "font-size: 24px; color: gray; cursor: pointer;");
            }
        });
        console.log(`Selected Rating: ${value}`);
    }
}
